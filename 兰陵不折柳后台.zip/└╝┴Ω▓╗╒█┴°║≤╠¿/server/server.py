#! �˴���дpython·��\python.exe
#coding=gbk
import cgi
import  shelve
import json
import smtplib
from email.mime.text import MIMEText
from email.header import  Header
form=cgi.FieldStorage()
flag=form['flag'].value
"""flag=orderΪ���Ͷ��� flag=loadGods Ϊ������Ʒ��Ϣ  flag=update Ϊ������Ʒ��Ϣ"""
print("Content-type:text/html\n")

if(flag=='modalImgs'):
    modalShelve=shelve.open(r'../data/modalImgs')
    modalStyle=form['modalStyle'].value
    modalImgs=modalShelve['modalImgs']
    imgs=modalImgs[modalStyle]
    modalShelve.close()
    imgs=json.dumps(imgs)
    print(imgs)
elif(flag=='advertisement'):
    adShelve=shelve.open(r'../data/advers')
    ads=adShelve['advers']
    adShelve.close()
    ads=json.dumps(ads)
    print(ads)
elif(flag=='loadGods'):
 
    godsShelve=shelve.open(r'../data/gods')
    gods=godsShelve['gods']
    godsShelve.close()
    gods=json.dumps(gods)
    print(gods)
#��ƷԤ��
elif(flag=='prevGods'):
    godsShelve=shelve.open(r'../data/prevGods')
    prevGods=godsShelve['prevGods']
    godsShelve.close()
    prevGods=json.dumps(prevGods)
    print(prevGods)

elif(flag=='order'):
    #ȡ�ö��������� style=gis Ϊ�ֻ�  adΪԤ��
    style=form['style'].value
    #���ﳵ����
    car=json.loads(form['car'].value)
    #�ջ�����Ϣ
    cusInfo=json.loads(form['cusInfo'].value)
    #��˰ʶ����Ϣ
    taxInfo=json.loads(form['taxInfo'].value)
    #�ܼ�
    moneyAll=form['moneyAll'].value
    #Ӧ��
    total=form['total'].value
    #�ۿ۽��
    cashOff=form['cashOff'].value
    #��ע
    remark=form['remark'].value

    _user = "�˴����Լ�������"
    _pwd  = "�˴���д�Լ��������Ȩ��"
    _to   = "�˴���д��������"
    html_header=r"""
    <!doctype html>
    <html lang="en">
     <head>
      <meta charset="UTF-8">
     </head>
     <style type="text/css">
     .main
     {
      width:100%;
      height:100%;
      margin-left:40%;
     }

     #section_price label:nth-child(1)
     {
      color:#E9546F
     }
     #section_price label:nth-child(2)
     {
      color:#9131E8
     }
     #section_price label:nth-child(3)
     {
      color:#E81302
     }
    th
    {
      background-color:#8E6CC6;
    }
    tr:nth-of-type(odd)
    {
      background-color:#7AD071;
    }
    tr:nth-of-type(even)
    {
     background-color:#EBE867;
    }
    tr td:nth-child(1)
    {
     width:220px;
    }
    tr td:nth-child(2)
    {

     width:120px;
    }
    tr td:nth-child(3)
    {

       width:100px;
    }
    #order
    {
       width:440px;
       text-align:center;
       font-size:20px;
       color:#843CF0;
       margin-bottom:20px;
    }
    #section_price
    {
      width:440px;
      text-align:right;
      margin-top:20px;
    }
    #section_price  label
    {
      margin-left:10px;
    }
    .address,.taxInfo,.remark
    {
      margin-left:40%;
    }
    .address label
    {
     margin-left:10px;
    }
    .address :nth-of-type(1)
    {
       margin-left:0px;
    }
     </style>
     <body>
     <div class="main">
     <div id='order'>��������</div>
       <table>"""
    html_table_header=''
    if(style=='gis'):
        html_table_header='<tr><th colspan="3">�ֻ���Ʒ</th></tr>'
    elif(style=='ad'):
        html_table_header='<tr><th colspan="3">��ƷԤ��</th></tr>'
    html_table_header=html_table_header+'<tr><th>��Ʒ����</th><th>��Ʒ���</th><th>��Ʒ����</th></tr>'
    html_table_money=(r"""</table>
          <div id="section_price"><label>�ϼ�:%s</label><label>�ۿ�:%s</label><label>���:%s</label></div></div>""" %(moneyAll,cashOff,total))
    html_end='</body></html>'
    html_cusInfo=(r"""<div class='address'><label>�ͻ�����:%s</label><label>����:%s</label><label>��ϸ��ַ:%s</label><label>��ϵ�绰:%s</label></div>"""
    %(cusInfo[0]['userName'],cusInfo[0]['cityName'],cusInfo[0]['detailInfo'],cusInfo[0]['telNumber']))
    html_taxInfo=(r"""<div class='taxInfo'><div >̧ͷ:%s</div>
                    <div >������:%s</div><div>��˰��:%s</div>
                    </div>"""
                  %(taxInfo['title'],taxInfo['bankName'],taxInfo['taxNumber']))
    html_remark=(r"""<div class='remark'>��ע:%s</div>"""%(remark))
    trs=[]
    for i in range(len(car)):
        #����  ��� ����
        tr=('<tr><td>%s</td><td>%s</td><td>%s</td></tr>'%(car[i]["name"],car[i]["id"],car[i]["num"]))
        trs.append(tr)
    trs=''.join(trs)
    #html=(html%(html,moneyAll,cashOff,total))
    html_table_content=html_table_header+trs
    html=html_header+html_table_content+html_table_money+html_cusInfo+html_taxInfo+html_remark+html_end
    #msg = MIMEText("name:%s;info:%s;num:%s;moneyAll:%s;cashOff:%s;Total:%s"%(car[0].name,car[0].info,car[0].num,moneyAll,cashOff,total),_subtype='html',_charset='utf-8')
    msg = MIMEText(html,_subtype='html',_charset='utf-8')
    msg["Subject"] = Header("������Ϣ",'utf-8')
    msg["From"]    = _user
    msg["To"]      = _to

    try:
        s = smtplib.SMTP_SSL("smtp.qq.com", 465)
        s.login(_user, _pwd)
        s.sendmail(_user, _to,msg.as_string())
        s.quit()
        print("success")


    except:
        print ("falied" )

else:
    print('hello world')

